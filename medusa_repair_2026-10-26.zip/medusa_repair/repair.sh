#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"

say() { printf '\n[repair] %s\n' "$*"; }
fail() { printf '\n[ERROR] %s\n' "$*" >&2; exit 1; }
command -v docker >/dev/null || fail 'Docker is not installed'
command -v python3 >/dev/null || fail 'Python3 is required'
[[ -f .env && -f compose.yaml && -f store/apps/backend/medusa-config.ts ]] || fail 'Run this script inside digital_store_medusa_kit after ./install.sh'

STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR=".repair-backups/$STAMP"
umask 077
mkdir -p "$BACKUP_DIR"
cp -p .env "$BACKUP_DIR/env.backup"
cp -p compose.yaml "$BACKUP_DIR/compose.yaml.backup"
cp -p store/apps/backend/medusa-config.ts "$BACKUP_DIR/medusa-config.ts.backup"
say "Backed up current configuration to $BACKUP_DIR (private)"

# Do not change the existing DB secret or reinitialize any Docker volume.
python3 - <<'PY'
from pathlib import Path
from urllib.parse import quote
import re

envfile=Path('.env')
lines=envfile.read_text().splitlines()
values={}
for line in lines:
    if '=' in line and not line.lstrip().startswith('#'):
        k,v=line.split('=',1)
        values[k]=v.strip().strip('"').strip("'")
password=values.get('POSTGRES_PASSWORD','')
if not password:
    raise SystemExit('Missing POSTGRES_PASSWORD in .env; existing database was not touched')
changes={
    'DATABASE_URL':'postgres://medusa:'+quote(password,safe='')+'@postgres:5432/medusa_store',
    'REDIS_URL':'redis://redis:6379',
}
for key,val in changes.items():
    replaced=False
    for i,line in enumerate(lines):
        if line.startswith(key+'='):
            lines[i]=key+'='+val
            replaced=True
            break
    if not replaced:
        lines.append(key+'='+val)
envfile.write_text('\n'.join(lines)+'\n')
envfile.chmod(0o600)

configpath=Path('store/apps/backend/medusa-config.ts')
config=configpath.read_text()
# Medusa's session Redis URL must be in projectConfig, not only in Docker environment.
if not re.search(r'\bredisUrl\s*:',config):
    changed,count=re.subn(r'(\bprojectConfig\s*:\s*\{)',r'\1\n    redisUrl: process.env.REDIS_URL,',config,count=1)
    if count!=1:
        raise SystemExit('Cannot locate projectConfig in medusa-config.ts; restore backup and inspect manually')
    configpath.write_text(changed)
print('Adjusted Medusa Redis configuration and retained existing PostgreSQL password.')
PY

say 'Checking Compose syntax'
docker compose config --quiet
say 'Starting database and Redis; leaving stored data intact'
docker compose up -d postgres redis

say 'Checking PostgreSQL password and database (no data changes)'
if ! docker compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" psql -h 127.0.0.1 -U medusa -d medusa_store -Atqc "SELECT 1"' | grep -qx '1'; then
  fail 'PostgreSQL authentication failed. This usually means an existing pg_data volume was initialized with an older password. DO NOT use docker compose down -v. See README-REPAIR.md.'
fi
say 'PostgreSQL credentials validated'

say 'Stopping storefront until a real publishable key is created'
docker compose stop storefront >/dev/null 2>&1 || true
say 'Rebuilding and starting the backend'
docker compose up -d --build --force-recreate backend

say 'Recent backend logs:'
docker compose logs --tail=45 backend
say 'Probe API endpoint after migrations complete:'
printf '    curl -i http://127.0.0.1:9000/health\n'
say 'When backend is healthy, open the Admin UI on port 9000 to create the publishable API key.'
