#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
[[ -f .env ]] || { echo '[ERROR] No .env found' >&2; exit 1; }
KEY="${1:-}"
if [[ ! "$KEY" =~ ^pk_[a-zA-Z0-9_-]+$ ]]; then
  echo 'Usage: ./start-storefront.sh pk_YOUR_REAL_PUBLISHABLE_KEY'
  echo 'Find the key in Medusa Admin > Settings > Publishable API Keys; associate it with the storefront sales channel.'
  exit 1
fi
python3 - "$KEY" <<'PY'
from pathlib import Path
import sys
f=Path('.env')
lines=f.read_text().splitlines()
key='NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY'
lines=[l for l in lines if not l.startswith(key+'=')]
lines.append(key+'='+sys.argv[1])
f.write_text('\n'.join(lines)+'\n')
f.chmod(0o600)
PY
docker compose up -d --force-recreate storefront
docker compose ps
docker compose logs --tail=35 storefront
