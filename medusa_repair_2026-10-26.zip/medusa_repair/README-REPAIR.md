# Digital Store repair, October 26 2026

The supplied logs show 2 independent failing services:
- backend repeatedly reports database migration timeout and `redisUrl not found`;
- storefront crashes because `NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY` is empty.

`repair.sh` (1) backs up `.env`, compose.yaml and medusa-config.ts, (2) retains the PostgreSQL password while making DATABASE_URL and REDIS_URL consistent, (3) injects `projectConfig.redisUrl` if missing, (4) checks PostgreSQL via psql, (5) stops the failing storefront, (6) rebuilds the backend. It **does not delete** volumes, create a fake publishable key, or automatically claim the store is production ready.

Upload both shell scripts into the existing `/root/s/digital_store_medusa_kit` directory and run:

```bash
cd /root/s/digital_store_medusa_kit
chmod +x repair.sh start-storefront.sh
./repair.sh
```

Then validate the backend:

```bash
docker compose ps
docker compose logs --tail=70 backend
curl -i http://127.0.0.1:9000/health
```

If API is healthy, create admin with `./admin-user.sh admin@example.com` if not created yet. Open `http://<SERVER_IP>:9000/app` **only for initial testing** (HTTP transmits credentials unencrypted; prefer HTTPS or SSH tunnel). Go to **Settings > Publishable API Keys**, create a publishable key, associate a sales channel, copy its token, and run:

```bash
./start-storefront.sh pk_YOUR_REAL_PUBLISHABLE_KEY
```

Then visit `http://<SERVER_IP>:8000` and check the storefront.

## Troubleshooting the DB timeout

If the PostgreSQL check fails, a pre-existing persistent volume may be initialized with a different password. Never run `docker compose down -v`; that deletes persistent data. A healthy PostgreSQL container means PostgreSQL is listening, **not** that Medusa can authenticate.

First inspect these without exposing secrets:

```bash
docker compose exec -T postgres pg_isready -U medusa -d medusa_store
docker compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" psql -h 127.0.0.1 -U medusa -d medusa_store -Atqc "SELECT 1"'
docker compose exec -T backend sh -c 'echo "DATABASE_URL configured: ${DATABASE_URL:+yes}"; echo "REDIS_URL configured: ${REDIS_URL:+yes}"'
docker compose logs --tail=70 postgres backend
```

If the database login succeeds but Medusa times out, run inside the Docker backend container (package/module issues may remain) and review log output:

```bash
docker compose run --rm --no-deps backend node -e 'const net=require("net");let s=net.connect(5432,"postgres",()=>{console.log("Docker network to Postgres OK");s.end()});s.on("error",e=>{console.error(e.message);process.exit(1)});s.setTimeout(5000,()=>{console.error("Postgres TCP timeout");s.destroy();process.exit(1)})'
```

The storefront cannot start without a real API key. No user data must be deleted to fix that.

These scripts were syntax-checked locally but not executed against the user's VPS. The Medusa upstream changes over time and installation/plugins may need further revisions.
